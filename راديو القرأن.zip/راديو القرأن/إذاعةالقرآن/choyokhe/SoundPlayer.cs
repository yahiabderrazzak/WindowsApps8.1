﻿namespace إذاعةالقرآن.choyokhe
{
    internal class SoundPlayer
    {
    }
}